import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Check, X, HelpCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const QuizInterfaceScreen = ({ quizzes, onQuizComplete }) => {
  const { quizId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [quizData, setQuizData] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    const currentQuiz = quizzes.find(q => q.id === quizId);
    if (currentQuiz) {
      setQuizData(currentQuiz);
    } else {
      navigate('/catalogo-quizzes'); 
    }
  }, [quizId, quizzes, navigate]);

  if (!quizData) {
    return <div className="p-4 text-center">Carregando quiz...</div>;
  }

  const currentQuestion = quizData.questions[currentQuestionIndex];
  const progressPercentage = ((currentQuestionIndex + 1) / quizData.questions.length) * 100;

  const handleAnswerSelect = (index) => {
    if (!isAnswerSubmitted) {
      setSelectedAnswer(index);
    }
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) {
      toast({ title: "Selecione uma resposta!", description: "Você precisa escolher uma opção para continuar.", variant: "destructive" });
      return;
    }
    setIsAnswerSubmitted(true);
    if (selectedAnswer === currentQuestion.correctAnswerIndex) {
      setScore(prevScore => prevScore + 1);
      toast({ title: "Correto!", description: "Mandou bem!", className: "bg-green-100 border-green-500 text-green-700" });
    } else {
      toast({ title: "Incorreto!", description: `A resposta correta era: ${currentQuestion.options[currentQuestion.correctAnswerIndex]}`, variant: "destructive" });
    }
  };

  const handleNextQuestion = () => {
    setSelectedAnswer(null);
    setIsAnswerSubmitted(false);
    if (currentQuestionIndex < quizData.questions.length - 1) {
      setCurrentQuestionIndex(prevIndex => prevIndex + 1);
    } else {
      onQuizComplete(quizId, score, quizData.questions.length);
      navigate(`/resultado-quiz/${quizId}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col p-4 md:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <Link to="/catalogo-quizzes" className="inline-flex items-center text-text-gray hover:text-primary-green group mb-2">
          <ArrowLeft className="mr-2 h-4 w-4 transition-transform group-hover:-translate-x-1" />
          Voltar ao Catálogo
        </Link>
        <h1 className="text-2xl md:text-3xl font-bold text-primary-green">{quizData.title}</h1>
        <p className="text-sm text-text-gray">Questão {currentQuestionIndex + 1} de {quizData.questions.length}</p>
      </motion.div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-2.5 mb-8">
        <motion.div
          className="bg-primary-green h-2.5 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${progressPercentage}%` }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
        />
      </div>

      {/* Question Card */}
      <motion.div
        key={currentQuestionIndex}
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -50 }}
        transition={{ duration: 0.4 }}
        className="bg-white p-6 md:p-8 rounded-xl shadow-xl card-shadow flex-grow flex flex-col"
      >
        <h2 className="text-xl md:text-2xl font-semibold text-text-dark mb-6">{currentQuestion.question}</h2>
        
        <div className="space-y-3 mb-8 flex-grow">
          {currentQuestion.options.map((option, index) => {
            let optionClass = "quiz-option";
            if (isAnswerSubmitted) {
              if (index === currentQuestion.correctAnswerIndex) {
                optionClass += " correct";
              } else if (index === selectedAnswer) {
                optionClass += " incorrect";
              }
            } else if (index === selectedAnswer) {
              optionClass += " selected";
            }

            return (
              <motion.button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                disabled={isAnswerSubmitted}
                className={`w-full p-4 rounded-lg text-left text-text-dark font-medium flex items-center justify-between ${optionClass}`}
                whileHover={!isAnswerSubmitted ? { scale: 1.02 } : {}}
                whileTap={!isAnswerSubmitted ? { scale: 0.98 } : {}}
              >
                <span>{option}</span>
                {isAnswerSubmitted && index === currentQuestion.correctAnswerIndex && <Check className="w-5 h-5 text-green-700" />}
                {isAnswerSubmitted && index === selectedAnswer && index !== currentQuestion.correctAnswerIndex && <X className="w-5 h-5 text-red-700" />}
              </motion.button>
            );
          })}
        </div>

        {isAnswerSubmitted && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 rounded-md mb-6 text-sm"
            style={{ backgroundColor: selectedAnswer === currentQuestion.correctAnswerIndex ? 'hsl(120, 70%, 95%)' : 'hsl(0, 100%, 97%)',
                     borderColor: selectedAnswer === currentQuestion.correctAnswerIndex ? 'hsl(120, 60%, 80%)' : 'hsl(0, 80%, 90%)',
                     borderWidth: '1px',
                     color: selectedAnswer === currentQuestion.correctAnswerIndex ? 'hsl(120, 60%, 30%)' : 'hsl(0, 70%, 40%)'
                  }}
          >
            <p className="font-semibold">Explicação:</p>
            <p>{currentQuestion.explanation}</p>
          </motion.div>
        )}

        <Button
          onClick={isAnswerSubmitted ? handleNextQuestion : handleSubmitAnswer}
          size="lg"
          className="w-full bg-primary-green hover:bg-primary-green-medium text-white mt-auto"
        >
          {isAnswerSubmitted ? (currentQuestionIndex < quizData.questions.length - 1 ? 'Próxima Pergunta' : 'Finalizar Quiz') : 'Confirmar Resposta'}
        </Button>
      </motion.div>
    </div>
  );
};

export default QuizInterfaceScreen;