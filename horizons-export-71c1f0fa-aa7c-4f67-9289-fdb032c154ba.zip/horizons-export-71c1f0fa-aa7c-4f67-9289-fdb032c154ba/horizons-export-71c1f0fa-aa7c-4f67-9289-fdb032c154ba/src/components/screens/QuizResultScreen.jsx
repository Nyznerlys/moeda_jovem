import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Award, Repeat, Home, CheckCircle, Star, Coins } from 'lucide-react';
import Confetti from 'react-confetti'; 

const QuizResultScreen = ({ quizzes, userProfile }) => {
  const { quizId } = useParams();
  const navigate = useNavigate();
  const [showConfetti, setShowConfetti] = useState(false);

  const quiz = quizzes.find(q => q.id === quizId);
  const result = userProfile.completedQuizzes[quizId];

  useEffect(() => {
    if (!quiz || !result) {
      navigate('/catalogo-quizzes'); 
      return;
    }
    if (result.score / result.totalQuestions >= 0.7) {
      setShowConfetti(true);
      const timer = setTimeout(() => setShowConfetti(false), 5000); 
      return () => clearTimeout(timer);
    }
  }, [quiz, result, navigate]);

  if (!quiz || !result) {
    return <div className="p-4 text-center">Carregando resultado...</div>;
  }

  const percentage = (result.score / result.totalQuestions) * 100;
  const passed = percentage >= 70;
  const earnedXP = result.score * 10;
  const earnedCoins = result.score * 5;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
      {showConfetti && <Confetti recycle={false} numberOfPieces={300} />}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, type: 'spring' }}
        className="bg-white p-8 md:p-12 rounded-xl shadow-2xl w-full max-w-lg text-center"
      >
        <motion.div
          className="celebration-animation mb-6"
        >
          {passed ? (
            <Award className="mx-auto h-20 w-20 text-yellow-500" />
          ) : (
            <CheckCircle className="mx-auto h-20 w-20 text-primary-green" />
          )}
        </motion.div>

        <h1 className="text-3xl md:text-4xl font-bold text-text-dark mb-3">
          {passed ? 'Parabéns, você arrasou!' : 'Resultado do Quiz'}
        </h1>
        <p className="text-lg text-text-gray mb-2">
          Você concluiu o quiz: <span className="font-semibold text-primary-green">{quiz.title}</span>
        </p>

        <div className="my-8">
          <p className="text-5xl md:text-7xl font-extrabold text-primary-green mb-2">
            {result.score}/{result.totalQuestions}
          </p>
          <p className="text-xl text-text-gray">
            ({percentage.toFixed(0)}% de acerto)
          </p>
        </div>

        {passed && (
          <motion.div 
            initial={{ opacity:0, y:20 }}
            animate={{ opacity:1, y:0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="space-y-3 bg-primary-green-light p-6 rounded-lg mb-8"
          >
            <div className="flex items-center justify-center gap-3 text-lg">
              <Star className="w-6 h-6 text-yellow-500" />
              <span className="font-semibold text-text-dark">+{earnedXP} XP ganhos!</span>
            </div>
            <div className="flex items-center justify-center gap-3 text-lg">
              <Coins className="w-6 h-6 text-yellow-600" />
              <span className="font-semibold text-text-dark">+{earnedCoins} Moedas ganhas!</span>
            </div>
          </motion.div>
        )}

        <div className="space-y-3">
          <Link to={`/quiz/${quizId}`}>
            <Button size="lg" variant="outline" className="w-full border-primary-green text-primary-green hover:bg-primary-green-light">
              <Repeat className="mr-2 h-5 w-5" /> Refazer Quiz
            </Button>
          </Link>
          <Link to="/catalogo-quizzes">
            <Button size="lg" className="w-full bg-primary-green hover:bg-primary-green-medium text-white">
              <Home className="mr-2 h-5 w-5" /> Ver Outros Quizzes
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default QuizResultScreen;