import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Home, Award, CheckCircle, Settings, Edit3, Star, Coins, User as UserIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

const UserProfileScreen = ({ userProfile, learningTracks, appName = "Moeda Jovem" }) => {
  const completedQuizzes = learningTracks.filter(track => userProfile.completedTracks.includes(track.id));
  const totalPossibleXP = learningTracks.reduce((sum, track) => sum + track.xp, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen bg-mj-green-light p-4 md:p-8 flex flex-col items-center"
    >
      <div className="w-full max-w-3xl">
        <header className="mb-8 flex justify-between items-center">
          <Link to="/quiz-catalog">
            <Button variant="ghost" className="text-mj-gray-text hover:bg-mj-green-medium/20">
              <Home className="w-5 h-5 mr-2" />
              Voltar ao Catálogo
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-mj-green">{appName} - Perfil</h1>
          <Button variant="ghost" className="text-mj-gray-text hover:bg-mj-green-medium/20">
            <Settings className="w-5 h-5" />
          </Button>
        </header>

        <main className="bg-white shadow-xl rounded-lg p-6 md:p-10">
          <section className="text-center mb-10">
            <div className="relative w-32 h-32 mx-auto mb-4">
              <img 
                className="w-full h-full rounded-full object-cover border-4 border-mj-green-medium"
                alt="Foto do perfil do usuário"
               src="https://images.unsplash.com/photo-1683600001448-e0793ce3be85" />
              <Button
                variant="outline"
                size="icon"
                className="absolute bottom-0 right-0 bg-mj-blue hover:bg-mj-blue/90 text-white rounded-full border-2 border-white"
              >
                <Edit3 className="w-5 h-5" />
              </Button>
            </div>
            <h2 className="text-3xl font-bold text-mj-green-dark mb-1">{userProfile.name}</h2>
            <p className="text-mj-gray-text">Nível {userProfile.level} - Entusiasta Financeiro</p>
          </section>

          <section className="mb-10">
            <h3 className="text-xl font-semibold text-mj-green-dark mb-4">Estatísticas</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-mj-green-light p-4 rounded-lg text-center">
                <p className="text-3xl font-bold text-mj-green">{userProfile.xp}</p>
                <p className="text-sm text-mj-gray-text">XP Total</p>
              </div>
              <div className="bg-mj-blue-light p-4 rounded-lg text-center">
                <p className="text-3xl font-bold text-mj-blue">{userProfile.coins}</p>
                <p className="text-sm text-mj-gray-text">Moedas</p>
              </div>
              <div className="bg-yellow-100 p-4 rounded-lg text-center">
                <p className="text-3xl font-bold text-yellow-500">{userProfile.streak}</p>
                <p className="text-sm text-mj-gray-text">Dias em Sequência</p>
              </div>
            </div>
          </section>

          <section className="mb-10">
            <h3 className="text-xl font-semibold text-mj-green-dark mb-4">Progresso Geral</h3>
            <div className="w-full bg-gray-200 rounded-full h-6 mb-2">
              <motion.div
                className="bg-mj-green h-6 rounded-full flex items-center justify-center text-white text-xs font-medium"
                initial={{ width: '0%' }}
                animate={{ width: `${(userProfile.xp / totalPossibleXP) * 100}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
              >
                {((userProfile.xp / totalPossibleXP) * 100).toFixed(0)}%
              </motion.div>
            </div>
            <p className="text-sm text-mj-gray-text text-center">Você completou {((userProfile.xp / totalPossibleXP) * 100).toFixed(0)}% de todas as trilhas!</p>
          </section>

          <section>
            <h3 className="text-xl font-semibold text-mj-green-dark mb-4">Quizzes Concluídos ({completedQuizzes.length})</h3>
            {completedQuizzes.length > 0 ? (
              <ul className="space-y-3">
                {completedQuizzes.map(track => (
                  <li key={track.id} className="flex items-center justify-between p-4 bg-mj-green-light rounded-lg">
                    <div className="flex items-center">
                      <div className={`p-2 rounded-full mr-3 bg-${track.id === 1 ? 'mj-green-medium' : track.id === 2 ? 'mj-blue' : 'yellow-400'}/20`}>
                        {React.cloneElement(track.icon, { className: `w-6 h-6 text-${track.id === 1 ? 'mj-green' : track.id === 2 ? 'mj-blue' : 'yellow-500'}` })}
                      </div>
                      <div>
                        <p className="font-medium text-mj-green-dark">{track.title}</p>
                        <p className="text-xs text-mj-gray-text">+{track.xp} XP</p>
                      </div>
                    </div>
                    <div className="flex items-center text-mj-green">
                      <Star className="w-5 h-5 mr-1 text-yellow-400" />
                      <Coins className="w-5 h-5 mr-1 text-yellow-500" />
                      <CheckCircle className="w-5 h-5 text-mj-green" />
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-mj-gray-text text-center py-4">Você ainda não completou nenhum quiz. <Link to="/quiz-catalog" className="text-mj-green hover:underline">Comece agora!</Link></p>
            )}
          </section>

          <section className="mt-10 text-center">
            <Button className="bg-mj-green hover:bg-mj-green-dark text-white px-8 py-3 rounded-lg text-base">
              Ver Conquistas
              <Award className="w-5 h-5 ml-2" />
            </Button>
          </section>
        </main>
      </div>
    </motion.div>
  );
};

export default UserProfileScreen;