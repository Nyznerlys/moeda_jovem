import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Filter, CheckCircle, Play, ArrowLeft } from 'lucide-react';

const QuizCard = ({ quiz, userProfile }) => {
  const isCompleted = userProfile.completedQuizzes && userProfile.completedQuizzes[quiz.id];
  const progress = isCompleted ? (userProfile.completedQuizzes[quiz.id].score / userProfile.completedQuizzes[quiz.id].totalQuestions) * 100 : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-white rounded-xl shadow-lg card-shadow overflow-hidden flex flex-col hover:shadow-xl transition-shadow duration-300"
    >
      <div className={`p-4 ${quiz.color} flex items-center justify-center h-32`}>
        {React.cloneElement(quiz.icon, { className: "w-16 h-16 opacity-80" })}
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-semibold text-text-dark mb-2">{quiz.title}</h3>
        <p className="text-sm text-text-gray mb-4 flex-grow line-clamp-3">{quiz.description}</p>
        <div className="text-xs text-text-gray mb-1">Categoria: {quiz.category}</div>
        
        {isCompleted && (
          <div className="my-2">
            <div className="flex items-center justify-between text-xs text-text-gray mb-1">
              <span>Progresso: {progress.toFixed(0)}%</span>
              <CheckCircle className="w-4 h-4 text-primary-green" />
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5">
              <div className="bg-primary-green h-1.5 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
          </div>
        )}

        <Link to={`/quiz/${quiz.id}`} className="mt-auto">
          <Button className="w-full bg-primary-green hover:bg-primary-green-medium text-white mt-4">
            <Play className="mr-2 h-4 w-4" /> {isCompleted ? 'Refazer Quiz' : 'Começar Quiz'}
          </Button>
        </Link>
      </div>
    </motion.div>
  );
};

const QuizCatalogScreen = ({ quizzes, userProfile }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const location = useLocation();

  React.useEffect(() => {
    const params = new URLSearchParams(location.search);
    const category = params.get('category');
    if (category) {
      setSelectedCategory(category);
    }
  }, [location.search]);

  const categories = useMemo(() => ['Todos', ...new Set(quizzes.map(q => q.category))], [quizzes]);

  const filteredQuizzes = useMemo(() => {
    return quizzes.filter(quiz => {
      const matchesSearch = quiz.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            quiz.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'Todos' || quiz.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [quizzes, searchTerm, selectedCategory]);

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          {location.search && (
             <Link to="/inicio" className="inline-flex items-center text-text-gray hover:text-primary-green mb-4 group">
                <ArrowLeft className="mr-2 h-4 w-4 transition-transform group-hover:-translate-x-1" />
                Voltar ao Início
            </Link>
          )}
          <h1 className="text-3xl md:text-4xl font-bold text-primary-green mb-2">Catálogo de Quizzes</h1>
          <p className="text-lg text-text-gray">Explore nossos desafios e teste seus conhecimentos financeiros!</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8 p-6 bg-white rounded-xl shadow-md card-shadow"
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Buscar quiz por título ou descrição..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 input-field w-full"
              />
            </div>
            <div className="relative md:w-1/3">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="pl-10 input-field w-full appearance-none"
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
          </div>
        </motion.div>

        {filteredQuizzes.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {filteredQuizzes.map(quiz => (
              <QuizCard key={quiz.id} quiz={quiz} userProfile={userProfile} />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <img  alt="Ilustração de busca vazia" className="w-40 h-40 mx-auto mb-4 opacity-50" src="https://images.unsplash.com/photo-1519310884615-5d202b967600" />
            <p className="text-xl text-text-gray">Nenhum quiz encontrado com esses filtros.</p>
            <p className="text-text-gray">Tente ajustar sua busca ou limpar os filtros.</p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default QuizCatalogScreen;